import requests
import time
import os

# ====== CONFIG ======
BOT_TOKEN = "8374905161:AAE3sO3G7Q2Rt4HUjLDAHxmEH1gmc-BZAtw"
CHAT_ID = "7660485006"
FILE_PATH = "results.txt"
INTERVAL = 20 * 60  # 20 minutes
# ====================

SEND_URL = f"http://157.250.198.96:8081/bot{BOT_TOKEN}/sendDocument"

# Ask for message when script starts
MESSAGE = input("Enter the message to send with the file: ")

def send_file():
    if not os.path.exists(FILE_PATH):
        print(f"[!] File not found: {FILE_PATH}")
        return

    with open(FILE_PATH, "rb") as f:
        response = requests.post(
            SEND_URL,
            data={
                "chat_id": CHAT_ID,
                "caption": MESSAGE
            },
            files={
                "document": f
            }
        )

    if response.status_code == 200:
        print("[+] File sent successfully")
    else:
        print("[-] Failed to send file:", response.text)

print("[*] Telegram file sender started")

while True:
    send_file()
    time.sleep(INTERVAL)